<?php 

  include "../../common/header.php";
  include "../nav.php"; 

  // $trainers= selectMamagementTrainerAttendance($conn);
    
?>
  
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <?php include "../../common/message.php"; ?>
      <h1>
        Trainer 
      </h1>
    </section>

    <!-- Main content -->
   
    <section class="content">
        <div class="row">
        
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="text-capitalize table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Trainer Name</th>
                    <th>Batch Name</th>
                    <th>Date</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Approve</th>
                    <th>Reject</th>
                    
                  </tr>
                </thead>
                <tbody>

                  <?php 
                   
                  $trainers= selectMamagementTrainerAttendance($conn);

                      if(mysqli_num_rows($trainers) > 0){

                        $all_batchs = "(";

                        $i = 1;
                        while($batch = mysqli_fetch_array($trainers)) {
                          
                          if($i == mysqli_num_rows($trainers)){
                            $end = ")";
                          }else{
                            $end = ",";
                          }

                          $all_batchs = $all_batchs.$batch['id'].$end;

                          $i++;

                        }

                      }else{
                        $all_batchs = '(0)';
                      }

                    $all_attendances = pendingTrainerAttendances($conn, $all_batchs, $_SESSION['user']['id']);
                   ?>
                  
                   
                    <?php if (mysqli_num_rows($all_attendances) > 0) { ?>
                      <?php while ($attendance = mysqli_fetch_array($all_attendances)) {  ?>

                                               
                            <tr>
                              <td><?php echo $attendance["name"]; ?></td>
                              <td><?php echo $attendance["title"]; ?></td>
                              <td><?php echo $attendance["date"]; ?></td>
                              <td><?php echo $attendance["rating"]; ?></td>
                              <td><?php echo $attendance["review"]; ?></td>
                              <td style="text-align: center;">
                                <a href='approve.php?approve=<?php echo $attendance["id"]; ?>'>
                                  <i class="fa fa-check"></i>
                                </a>
                              </td>
                              <td style="text-align: center;">
                                <a href='approve.php?reject=<?php echo $attendance["id"]; ?>'>
                                  <i class="fa fa-close"></i>
                                </a>
                              </td>
                              
                            </tr>
                          
                      <?php } ?>  
                    <?php } ?>      
                
                </tbody>
                <tfoot>
                  <tr>
                    <th>Trainer Name</th>
                    <th>Batch Name</th>
                    <th>Date</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Approve</th>
                    <th>Reject</th>
                    
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- DataTables -->
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

   <script type="text/javascript">
    $(function() {
        nav_highlight("attendance", "trainer-add");
    });
  </script>

<?php include "../../common/footer.php"; ?>
