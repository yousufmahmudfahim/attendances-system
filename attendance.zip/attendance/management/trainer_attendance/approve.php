<?php 
	include '../../common/header.php';

  // print_r($_GET); exit();
 ?>
  

 <?php if (isset($_GET['pending'])) {

  $id = $_GET['pending'];

 	$fields = array('pending');

 	$values = array(0);

 	$condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);

 	$result = updateRowWithOneCondition($conn, "attendances", $fields, $values, $condition); 
  // print_r($result); exit;

 	if($result == 1){
    $_SESSION['success'] = "Pending Successfully";
    goToError($base_url."/management/trainer_attendance/trainer_manage.php");
  }else{
    $_SESSION['error'] = "Something Went Wrong ! Plese try again";
    goToError($base_url."/management/trainer_attendance/trainer_manage.php");
  }


 }elseif (isset($_GET['reject'])) {
 	$id = $_GET['reject'];

 	$fields = array('approved');

 	$values = array(2);

 	$condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);

 	$result = updateRowWithOneCondition($conn, "attendances", $fields, $values, $condition);

 	if($result == 1){
    $_SESSION['success'] = "Rejected Successfully";
    goToError($base_url."/management/trainer_attendance/trainer_atte.php");
  }else{
    $_SESSION['error'] = "Something Went Wrong ! Plese try again";
    goToError($base_url."/management/trainer_attendance/trainer_atte.php");
  }

 }else{
   	$_SESSION['error'] = "You Can't View This Page";
  	goToError($base_url."/management/trainer_attendance/trainer_atte.php");
 } 

 ?>