<?php

  include "../../common/header.php";
  include "../nav.php";

 
    // $sql = "SELECT attendances.id, attendances.approved
    //       FROM attendances";
    //   $attendance = mysqli_query($conn, $sql);

    $id = $_GET['id'];

    // print_r($_GET); exit;

    $condition_one = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);
    // $condition_two = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
    $update_atten = selectSingleTableWithOneCondition($conn, 'attendances', $condition_one);
    // print_r($update_atten); exit;



?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "../../common/message.php"; ?>
      
      <h1>
        Attendance
        <small>Edit</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Fill the form</h3>
            </div>
            <!-- /.box-header -->
            <div>

              <?php if (mysqli_num_rows($update_atten) > 0) { ?>
                <?php while ($update_attendance = mysqli_fetch_array($update_atten)) { ?>

                  <a href="approve.php?pending=<?php echo $update_attendance["id"]; ?>" class="btn btn-info">Pending</a>

                  <a href="" class="btn btn-info">Approved</a>
                  <a href="" class="btn btn-info">Reject</a>
                  
                <?php } ?>
              <?php } ?>

              
            </div>
              
          </div>
          <!-- /.box -->

        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    $(function() {
        nav_highlight("attendance", "trainer-manage");
    });
  </script>

<?php include "../../common/footer.php"; ?>
