<?php 
  include "../../common/header.php";
  include "../nav.php"; 

  // Fatching Users
  if(isset($_GET)){
     $batches = selectBatchList($conn, $_GET);
  }else{
     $batches = selectBatchList($conn);
  }
  
  $trainer_condition = array('field_name' => 'role_id', 'condition' => 'equal', 'field_value' => '2');
  $trainer_condition_two = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $trainers = selectSingleTableWithTwoCondition($conn, 'users', $trainer_condition,$trainer_condition_two);


?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    
      <?php include "../../common/message.php"; ?>

      <h1>
        Dashboard
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Filter</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="GET">
                <div class="box-body">
                  <?php if (isset($_GET['code'])) { $code = $_GET['code'];} else{ $code = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>coad</label>
                    <input type="text" name="code" class="form-control" placeholder="code" value="<?php echo $code; ?>" id="code">
                  </div>

                  <?php if(isset($_GET['title'])){ $title = $_GET['title']; } else { $title = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>title</label>
                    <input type="text" name="title" class="form-control" placeholder="title" value="<?php echo $title; ?>" id="title">
                  </div>
                  <?php if(isset($_GET['class_limit'])){ $class_limit = $_GET['class_limit']; } else { $class_limit = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>class limit</label>
                    <input type="text" name="class_limit" class="form-control" placeholder="class limit" value="<?php echo $class_limit; ?>" id="class_limit">
                  </div>
                  

                  <?php if (mysqli_num_rows($trainers) > 0) { ?>
                    <?php if(isset($_GET['trainer_name'])){ $name = $_GET['trainer_name']; } else { $name = ""; } ?>
                    <div class="form-group col-md-4">
                      <label>trainer</label>
                      
                        <select name="trainer_name" class="form-control" id="trainer_name">
                          <option value="">select trainer</option>
                            <?php while ($trainer = mysqli_fetch_array($trainers)) { ?>
                              <option value="<?php echo $trainer['id']; ?>" <?php if($name == $trainer['id']) 
                              { echo "selected='selected'";} ?> > 
                              <?php echo $trainer['name']; ?>
                              </option>
                            <?php } ?>
                      
                          </option>
                        </select>
                      </div>
                  <?php } ?>  
                  
                  <?php if(isset($_GET['course_name'])){ $course_name = $_GET['course_name']; } else { $course_name = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>course</label>
                    <input type="text" name="course_name" class="form-control" placeholder="course" value="<?php echo $course_name; ?>" id="course_name">
                  </div>

                  <?php if(isset($_GET['status'])){ $status = $_GET['status']; } else { $status = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>Role</label>
                    <select name="status" class="form-control" id="status">
                      <option value="">All</option>
                        <option value="1" <?php if($status == 1){ echo "selected='selected'"; } ?> >
                          Active                          
                        </option>
                        <option value="0" <?php if($status === '0'){ echo "selected='selected'"; } ?> >
                          Inactive                          
                        </option>
                    </select>
                  </div>

                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <!-- <button type="reset" class="btn btn-default" onclick="customReset();">Reset</button> -->
                  <a class="btn btn-default" href="<?php echo parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH) ?>">
                    Reset
                  </a>
                  <button type="submit" class="btn btn-primary pull-right">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>code</th>
                    <th>title</th>
                    <th>class_limit</th>
                    <th>trainer name</th>
                    <th>course name</th>
                    <th>update</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(mysqli_num_rows($batches) > 0){ ?>

                      <?php while($batch = mysqli_fetch_array($batches)) { ?>
                          
                        <tr>
                          <td><?php echo $batch["code"]; ?></td>
                          <td><?php echo $batch["title"]; ?></td>
                          <td><?php echo $batch["class_limit"]; ?></td>
                          <td><?php echo $batch["name"]; ?></td>
                          <td><?php echo $batch["course_name"]; ?></td>
                          <td style="text-align: center;">
                            <a href='edit.php?id=<?php echo $batch["id"]; ?>'>
                              <i class="fa fa-pencil"></i>
                            </a>
                          </td>
                          <td style="text-align: center;">
                            <a href='delete.php?id=<?php echo $batch["id"]; ?>'>
                              <i class="fa fa-close"></i>
                            </a>
                          </td>
                        </tr>

                      <?php } ?>

                  <?php } ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>code</th>
                    <th>title</th>
                    <th>class_limit</th>
                    <th>trainer name</th>
                    <th>course name</th>
                    <th>update</th>
                    <th>Delete</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 <!-- DataTables -->
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

  <script type="text/javascript">
    $(function() {
        nav_highlight("batch", "batch-manage");
    });
  </script>

<?php include "../../common/footer.php"; ?>
