<?php 

	include "../../common/header.php";

	$fields = array('code', 'title', 'description', 'class_limit', 'trainer_id', 'course_id');
	$values = array($_POST['code'], $_POST['title'], $_POST['description'], $_POST['class_limit'], $_POST['trainer_id'], $_POST['course_id']);
	$new_id = insertNew($conn, 'batches', $fields, $values);

	// echo $new_id; exit;

	if($new_id){
		$_SESSION['success'] = "batch created successfully";
		goToError($base_url."/management/batch/manage.php");
	}else{
		$_SESSION['error'] = "Failed to insert course";
		goToError($base_url."/management/batch/add.php");
	}

 ?>