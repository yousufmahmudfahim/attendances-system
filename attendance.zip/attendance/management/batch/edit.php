<?php 
  include "../../common/header.php";

  if(!isset($_GET['id']) || $_GET['id'] == ""){
    goToError($base_url."/common/403.php");
  }

  include "../nav.php";

  // trainer name
  $trainer_condition = array('field_name' => 'role_id', 'condition' => 'equal', 'field_value' => '2');
  $trainers = selectSingleTableWithOneCondition($conn, 'users', $trainer_condition);


  // course name
  $course_condition = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $courses = selectSingleTableWithOneCondition($conn, 'courses', $course_condition);


  $batch_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $_GET['id']);
  $batch = selectSingleTableWithOneCondition($conn, 'batches', $batch_condition);

  if (mysqli_num_rows($batch) > 0) {
    $batches = mysqli_fetch_array($batch);
  }else{
    goToError($base_url."/common/403.php");
  }

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">


      <?php include "../../common/message.php"; ?>

      <h1>
        batch
        <small>Add</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <?php 
        include "../../common/message.php";
       ?>

      <form role="form" method="POST" action="update.php">
              <div class="box-body">
                <div class="form-group">
                  
                  <input type="hidden" name="id" required="required" value="<?php echo $batches['id']; ?>">

                  <label for="code">Batch Code*</label>
                  <input  name="code" type="text" class="form-control" id="code" placeholder="Enter batch code" value="<?php echo $batches['code'] ?>" required="required">
                </div>
                
                <div class="form-group">
                  <label for="title">Title*</label>
                  <input  name="title" type="text" class="form-control" id="title" placeholder="Enter Title" value="<?php echo $batches['title'] ?>" required="required">
                </div>
                
                <div class="form-group">
                  <label for="description">Description</label>
                  <textarea  name="description" class="form-control" id="description" required="required"><?php echo $batches['description'] ?></textarea>
                </div>

                <div class="form-group">
                  <label for="class_limit">class limit</label>
                  <input  name="class_limit" type="number" class="form-control" id="class_limit" placeholder="Enter class limit" value="<?php echo $batches['class_limit'] ?>" required="required">
                </div>

                <div class="form-group">
                  <label for="trainer_id">Trainer Name</label>

                  <?php if (mysqli_num_rows($trainers) > 0) { ?>
                    <select  name="trainer_id" id="trainer_id" class="form-control" required="required">
                      <option>Select Trainer</option>
                      <?php while ($trainer = mysqli_fetch_array($trainers)) { ?>
                        <option value="<?php echo $trainer['id']; ?>" <?php if($trainer['id'] == $batches['trainer_id']){ echo 'selected="selected"'; } ?>> <?php echo $trainer['name'];?> </option>
                      <?php } ?>                    
                    </select>
                  <?php } ?>
                </div>

                <div class="form-group">
                  <label for="course_id">Course Name</label>
                    <?php if (mysqli_num_rows($courses) > 0) { ?>
                        <select name="course_id" id="course_id" class="form-control" required="required">
                          <option>Select Course</option>
                          <?php while ($course = mysqli_fetch_array($courses)) {?>
                            <option value="<?php echo $course['id'];?>" <?php if($course['id'] == $batches['course_id']){ echo 'selected="selected"'; } ?> ><?php echo $course['title']; ?></option>
                          <?php } ?>                          
                        </select>              
                    <?php } ?>                  
                </div>                                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    $(function() {
        nav_highlight("batch", "batch-manage");
    });
  </script>

<?php include "../../common/footer.php"; ?>
