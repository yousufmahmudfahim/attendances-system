<?php 
  include "../../common/header.php";
  include "../nav.php"; 

  // trainer name
  $trainer_condition = array('field_name' => 'role_id', 'condition' => 'equal', 'field_value' => '2');
  $trainers = selectSingleTableWithOneCondition($conn, 'users', $trainer_condition);

  // course name
  $course_condition = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $courses = selectSingleTableWithOneCondition($conn, 'courses', $course_condition);

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        batch
        <small>Add</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <?php 
        include "../../common/message.php";
       ?>

      <form role="form" method="POST" action="insert.php">
              <div class="box-body">
                <div class="form-group">
                  <label for="code">Batch Code*</label>
                  <input  name="code" type="text" class="form-control" id="code" placeholder="Enter batch code" required="required">
                </div>
                
                <div class="form-group">
                  <label for="title">Title*</label>
                  <input  name="title" type="text" class="form-control" id="title" placeholder="Enter Title" required="required">
                </div>
                
                <div class="form-group">
                  <label for="description">Description</label>
                  <textarea  name="description" class="form-control" id="description"  required="required"></textarea>
                </div>

                <div class="form-group">
                  <label for="class_limit">class limit</label>
                  <input  name="class_limit" type="number" class="form-control" id="class_limit" placeholder="Enter class limit" required="required">
                </div>

                <div class="form-group">
                  <label for="trainer_id">Trainer Name</label>

                  <?php if (mysqli_num_rows($trainers) > 0) { ?>
                    <select  name="trainer_id" id="trainer_id" class="form-control" required="required">
                      <option>Select Trainer</option>
                      <?php while ($trainer = mysqli_fetch_array($trainers)) { ?>
                        <option value="<?php echo$trainer['id']; ?>"> <?php echo $trainer['name'];?> </option>
                      <?php } ?>                    
                    </select>
                  <?php } ?>
                </div>

                <div class="form-group">
                  <label for="course_id">Course Name</label>
                    <?php if (mysqli_num_rows($courses) > 0) { ?>
                        <select name="course_id" id="course_id" class="form-control" required="required">
                          <option>Select Course</option>
                          <?php while ($course = mysqli_fetch_array($courses)) {?>
                            <option value="<?php echo $course['id']; ?>" ><?php echo $course['title']; ?></option>
                          <?php } ?>                          
                        </select>              
                    <?php } ?>                  
                </div>
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    $(function() {
        nav_highlight("batch", "batch-add");
    });
  </script>

<?php include "../../common/footer.php"; ?>
