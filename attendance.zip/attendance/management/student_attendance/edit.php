<?php

  include "../../common/header.php";
  include "../nav.php";

  $user_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $_GET['id']);
  $user = selectSingleTableWithOneCondition($conn, 'attendances', $user_condition);
  if(mysqli_num_rows($user) > 0){
    $user = mysqli_fetch_array($user);
  }else{
    goToError($base_url."/common/403.php");
  }

  $attendance = selectMamagementStudentAttendance($conn);

  // print_r($user); exit();
  
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "../../common/message.php"; ?>
      
      <h1>
        Attendance
        <small>Edit</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Fill the form</h3>
            </div>
            <!-- /.box-header -->

            
          </div>
          <!-- /.box -->

        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    $(function() {
        nav_highlight("student-attendance", "student-manage");
    });
  </script>

<?php include "../../common/footer.php"; ?>
