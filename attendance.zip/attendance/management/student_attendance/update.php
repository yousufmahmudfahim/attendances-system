<?php

	include "../../common/header.php";

	if(!isset($_POST['id']) || $_POST['id'] == ""){
	    goToError($base_url."/common/403.php");
	}

	
	$id = $_POST['id'];

	$user_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);
	$user = selectSingleTableWithOneCondition($conn, 'attendances', $user_condition);

	if(mysqli_num_rows($user) > 0){

		$fields = array('attendance');
		$values = array($_POST['attendance']);
		

		$user_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);
		$user_condition_two = array('field_name' => 'attendance', 'condition' => 'equal', 'field_value' => 'approved');
		$result = updateRowWithTwoCondition($conn, "attendances", $fields, $values, $user_condition,$user_condition_two);

		// print_r($result); exit;

		if($result == 1){
			$_SESSION['success'] = "User updated successfully";
			goToError($base_url."/management/student_attendance/student_manage.php");
		}else{
			$_SESSION['error'] = "Failed to update user";
			goToError($base_url."/management/student_attendance/edit.php?id=".$id);
		}

	}else{
	    $_SESSION['error'] = "No user found with this ID";
	    goToError($base_url."/management/student_attendance/student_manage.php");
	}