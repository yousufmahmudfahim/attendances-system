<?php 

  // print_r($_POST); exit();
  include "../../common/header.php";

  if(!isset($_GET['id']) || $_GET['id'] == ""){
    goToError($base_url."/common/403.php");
  }

  include "../nav.php";

 

  // notice type
  $condition = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $notice = selectSingleTableWithOneCondition($conn, 'notices_types', $condition);

  // batch
  $condition = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $batch = selectSingleTableWithOneCondition($conn, 'batches', $condition);


  $notice_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $_GET['id']);
  $result = selectSingleTableWithOneCondition($conn, 'notices', $notice_condition);

  if (mysqli_num_rows($result) > 0) {
    $select = mysqli_fetch_array($result);
  }else{
    goToError($base_url."/common/403.php");
  }

?>

  <!-- date and time start  -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->
  <!-- date and time end -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "../../common/message.php"; ?>
      
      <h1>
        Notice
        <small>update</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        <form role="form" method="POST" action="update.php">
              <div class="box-body">

                <div class="form-group">

                  <input type="hidden" name="id" required="required" value="<?php echo $select['id']; ?>">

                  <input  name="created_by" type="hidden" class="form-control" id="created_by" value="<?php echo $_SESSION['user']['id']; ?>">
                 
                </div>
                
                <div class="form-group">
                  <label for="notice_type">Notice type*</label>
                  <?php if (mysqli_num_rows($notice) > 0) { ?>
                    <select name="notice_type" class="form-control" id="notice_type" required="required">
                      <option value="">select type</option>
                      <?php while ($notices = mysqli_fetch_array($notice)) { ?>
                        <option value="<?php echo $notices['id']; ?>" <?php if($notices['id'] == $select['notice_type_id']){ echo 'selected="selected"'; } ?>><?php echo $notices['title']; ?></option>
                      <?php } ?>
                  </select>
                  <?php } ?>
                </div>
                
                <div class="form-group">
                  <label for="title">Title*</label>
                  <input  name="title" type="text" class="form-control" id="title" placeholder="Enter Notice Title" required="required" value="<?php echo $select['title']; ?>">
                </div>

                <div class="form-group">
                  <label for="description">Description*</label>
                  <textarea  name="description" class="form-control" id="description"  required="required"><?php echo $select['description']; ?></textarea>
                </div>

                <div class="form-group">
                  <label for="batch_id">Batch Id*</label>
                  <?php if (mysqli_num_rows($batch) > 0) { ?>
                    <select name="batch_id" class="form-control" id="batch_id" required="required">
                      <option value="">select batch</option>
                      
                      <?php while ($batches = mysqli_fetch_array($batch)) { ?>
                        <option value="<?php echo $batches['id']; ?>" <?php if($batches['id'] == $select['batch_id']){ echo 'selected="selected"';} ?>><?php echo $batches['title']; ?></option>
                      <?php } ?>
                  </select>
                  <?php } ?>
                </div>

                 <!-- Date range -->
              <div class="form-group">
                <label>Start At:</label>

                  <div class='input-group date datetimepicker1'>
                      <input value="<?php echo $select['start_at']; ?>" type='text' class="form-control" name="start_at" class="form-control pull-right" />
                      <span class="input-group-addon">
                          <span class="glyphicon glyphicon-calendar"></span>
                      </span>
                  </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->

               <!-- Date range -->
              <div class="form-group">
                <label>Finish At:</label>

                <div class='input-group date datetimepicker1'>
                    <input value="<?php echo $select['finish_at']; ?>" type='text' class="form-control" name="finish_at" class="form-control pull-right" />
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->

                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
      </form>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

   <script type="text/javascript">
    $(function() {
        nav_highlight("notice", "notice-manage");
        $('.datetimepicker1').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss'
        });
    });
  </script>

<?php include "../../common/footer.php"; ?>
