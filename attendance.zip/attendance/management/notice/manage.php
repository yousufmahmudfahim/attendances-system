<?php

  include "../../common/header.php";
  include "../nav.php";

  
  if(isset($_GET)){
     $notices = selectNoticeList($conn, $_GET);
  }else{
     $notices = selectNoticeList($conn);
  }

?>

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "../../common/message.php"; ?>

      <h1>
        Notice
        <small>View</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Filter</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="GET">
                <div class="box-body">
                  
                    <?php if(isset($_GET['created_by'])){ $created = $_GET['created_by']; } else { $created = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>created by</label>
                    <input type="text" name="created_by" class="form-control" placeholder="created by" value="<?php echo $created; ?>" id="created_by">
                  </div>
                 


                  <?php if (isset($_GET['notice_type'])) { $notice_type = $_GET['notice_type'];} else{ $notice_type = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>notice type</label>
                    <input type="text" name="notice_type" class="form-control" placeholder="notice type" value="<?php echo $notice_type; ?>" id="notice_type">
                  </div>

                  <?php if(isset($_GET['title'])){ $title = $_GET['title']; } else { $title = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>title</label>
                    <input type="text" name="title" class="form-control" placeholder="title" value="<?php echo $title; ?>" id="title">
                  </div>


                  <?php if(isset($_GET['batch_id'])){ $batch_id = $_GET['batch_id']; } else { $batch_id = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>Batch Id</label>
                    <input type="text" name="batch_id" class="form-control" placeholder="batch id" value="<?php echo $batch_id; ?>" id="batch_id">
                  </div>


                  <?php if(isset($_GET['start_date'])){ $start_date = $_GET['start_date']; } else { $start_date = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>Start Date</label>

                    <input type="date" name="start_date" class="form-control" placeholder="start date" value="<?php echo $start_date; ?>" id="start_date">

                    <!-- <div class='input-group date datetimepicker1'>
                        <input type='text' class="form-control" name="start_date" value="<?php echo $start_date; ?>" class="form-control pull-right" />
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div> -->
                  </div>


                  <?php if(isset($_GET['finish_date'])){ $finish_date = $_GET['finish_date']; } else { $finish_date = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>Finish Date</label>

                    <input type="date" name="finish_date" class="form-control" placeholder="finish date" value="<?php echo $finish_date; ?>" id="finish_date">

                    <!-- <div class='input-group date datetimepicker1'>
                        <input type='text' class="form-control" name="start_date" value="<?php echo $start_date; ?>" class="form-control pull-right" />
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div> -->
                  </div>

                  <?php if(isset($_GET['status'])){ $status = $_GET['status']; } else { $status = ""; } ?>
                  <div class="form-group col-md-4">
                    <label>Role</label>
                    <select name="status" class="form-control" id="status">
                      <option value="">All</option>
                        <option value="1" <?php if($status == 1){ echo "selected='selected'"; } ?> >
                          Active                          
                        </option>
                        <option value="0" <?php if($status === '0'){ echo "selected='selected'"; } ?> >
                          Inactive                          
                        </option>
                    </select>
                  </div>

                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <!-- <button type="reset" class="btn btn-default" onclick="customReset();">Reset</button> -->
                  <a class="btn btn-default" href="<?php echo parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH) ?>">
                    Reset
                  </a>
                  <button type="submit" class="btn btn-primary pull-right">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>




       <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>created by</th>
                    <th>notice type</th>
                    <th>title</th>
                    <th>description</th>
                    <th>batch id</th>
                    <th>start at</th>
                    <th>finish at</th>
                    <th>update</th>
                    <th>delete</th>
                  </tr>
                </thead>
                <tbody>
                                            
                  <?php if (mysqli_num_rows($notices) > 0) { ?>

                    <?php while ($notice = mysqli_fetch_array($notices)) { ?>
                      <tr>
                        <th><?php echo $notice['name']; ?></th>
                        <th><?php echo $notice['notice_type']; ?></th>
                        <th><?php echo $notice['notice_title']; ?></th>
                        <th><?php echo $notice['description']; ?></th>
                        <th><?php echo $notice['batches_title']; ?></th>
                        <th><?php echo $notice['start_at']; ?></th>
                        <th><?php echo $notice['finish_at']; ?></th>
                        <td style="text-align: center;">
                            <a href='edit.php?id=<?php echo $notice["id"]; ?>'>
                              <i class="fa fa-pencil"></i>
                            </a>
                          </td>
                          <td style="text-align: center;">
                            <a href='delete.php?id=<?php echo $notice["id"]; ?>'>
                              <i class="fa fa-close"></i>
                            </a>
                          </td>
                        </tr>
                      </tr>
                    <?php } ?>
                    
                  <?php } ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>created by</th>
                    <th>notice type</th>
                    <th>title</th>
                    <th>description</th>
                    <th>batch id</th>
                    <th>start at</th>
                    <th>finish at</th>
                    <th>update</th>
                    <th>delete</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- DataTables -->
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

  <script type="text/javascript">
    $(function() {
        nav_highlight("notice", "notice-manage");

        $('.datetimepicker1').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss'
        });
    });
  </script>

<?php include "../../common/footer.php"; ?>
