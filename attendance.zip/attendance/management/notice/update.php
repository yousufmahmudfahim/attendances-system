<?php 

	include "../../common/header.php";

	$fields = array('created_by', 'notice_type_id', 'title', 'description', 'batch_id', 'start_at', 'finish_at');
	$values = array($_POST['created_by'], $_POST['notice_type'], $_POST['title'], $_POST['description'], $_POST['batch_id'], $_POST['start_at'], $_POST['finish_at']);
	
	$id = $_POST['id'];
	// echo $new_id; exit;
	$notice_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $id);
	$result = updateRowWithOneCondition($conn, "notices", $fields, $values, $notice_condition);


	if($result){
		$_SESSION['success'] = "notice updated successfully";
		goToError($base_url."/management/notice/manage.php");
	}else{
		$_SESSION['error'] = "Failed to update notice";
		goToError($base_url."/management/notice/manage.php");
	}


 ?>