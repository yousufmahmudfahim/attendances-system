<?php
    

  include "../../common/header.php";
  include "../nav.php";

  $attendance = selectTrainerAttendance($conn, $_SESSION['user']['id']);

    


?>

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "../../common/message.php"; ?>

      <h1>
        Trainer
        <small>View</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List</h3>
              </div>
            <!-- /.box-header -->

            

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Batch</th>
                    <th>Date</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Approved</th>
                    
                  </tr>
                </thead>
                <tbody>
                  
                   
                    <?php if (mysqli_num_rows($attendance) > 0) { ?>
                      <?php while ($attendances = mysqli_fetch_array($attendance)) {  ?>

                                               
                            <tr>
                              <td><?php echo $attendances["title"]; ?></td>
                              <td><?php echo $attendances["date"]; ?></td>
                              <td><?php echo $attendances["rating"]; ?></td>
                              <td><?php echo $attendances["review"]; ?></td>
                              <td><?php if ($attendances['approved']== 1){echo "Approved";}elseif($attendances['approved']== 2){echo "reject";}else{echo "pending";} ?></td>
                              
                            </tr>
                          
                      <?php } ?>  
                    <?php } ?>      
                
                </tbody>
                <tfoot>
                  <tr>
                    <th>Batch</th>
                    <th>Date</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Approved</th>b 
                    
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- DataTables -->
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo $base_url; ?>/assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

  <script type="text/javascript">
    $(function() {
        nav_highlight("attendance", "attendance-manage");
    });

    // function customReset(){
    //     document.getElementById("name").value = "";
    //     document.getElementById("msisdn").value = "";
    //     document.getElementById("email").value = "";
    //     document.getElementById("role_id").value = "";
    // }

  </script>

<?php include "../../common/footer.php"; ?>
