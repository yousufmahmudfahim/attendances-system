<?php 

  include "common/header.php";


?>


<body class="hold-transition register-page">
<div class="register-box" style="margin-top: 10px; margin-bottom: 0;">
  <div class="register-logo">
    <p style="color: white;">View Profile</p>
  </div>

  <?php include "common/message.php"; ?>

  <div class="register-box-body">

    <a href="<?php echo $base_url; ?>" class="btn btn-primary">Home</a>
    <p class="login-box-msg">Welcome</p>

    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              
              <img class="profile-user-img img-responsive img-circle" src="<?php echo $profile_data['image'] ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $profile_data['name']; ?></h3>

              <p class="text-muted text-center"><?php echo $profile_data['role']; ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Name :</b> <a class="pull-right"><?php echo $profile_data['name']; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Position :</b> <a class="pull-right"><?php echo $profile_data['role']; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Mobile :</b> <a class="pull-right"><?php echo $profile_data['msisdn']; ?></a>
                </li>
                <li class="list-group-item">
                  <b>E-mail :</b> <a class="pull-right"><?php echo $profile_data['email']; ?></a>
                </li>
              </ul>

              <a href="<?php echo $base_url.'/edit_profile.php' ?>" class="btn btn-primary btn-block"><b>Edit Profile</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
  </div>
  <!-- /.form-box -->
</div>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->
</body>

<!-- jQuery 3 -->
<!-- <script src="/assets/bower_components/jquery/dist/jquery.min.js"></script> -->
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $base_url; ?>/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $base_url; ?>/assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $base_url; ?>/assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $base_url; ?>/assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $base_url; ?>/assets/dist/js/demo.js"></script>


</html>