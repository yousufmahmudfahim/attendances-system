 <?php

	function conditionDefine($element){

		switch ($element["condition"]) {
			case 'equal':
					$text = $element["field_name"].' = "'.$element["field_value"].'"';
				break;

			case 'not_equal':
					$text = $element["field_name"].' != "'.$element["field_value"].'"';
				break;
			
			default:
					$text = $element["field_name"].' = "'.$element["field_value"].'"';
				break;
		}

		return $text;
	}

	function selectSingleTableWithTwoCondition($conn, $table_name, $condition_one, $condition_two){

		$sql = "SELECT * FROM $table_name
					WHERE ".conditionDefine($condition_one)."
					AND ".conditionDefine($condition_two);  

		return $result = mysqli_query($conn, $sql);

	}

	function selectSingleTableWithThreeCondition($conn, $table_name, $condition_one, $condition_two, $condition_three){

		$sql = "SELECT * FROM $table_name
					WHERE ".conditionDefine($condition_one)."
					AND ".conditionDefine($condition_two)."
					AND ".conditionDefine($condition_three);

		return $result = mysqli_query($conn, $sql);

	}
	

	function selectSingleTableWithNoCondition($conn, $table_name){

		$sql = "SELECT * FROM $table_name";

		return $result = mysqli_query($conn, $sql);

	}

	function selectSingleTableWithOneCondition($conn, $table_name, $condition){

		$sql = "SELECT * FROM $table_name
					WHERE ".conditionDefine($condition);

		return $result = mysqli_query($conn, $sql);

	}

	function insertNew($conn, $table_name, $fields, $values){

		$fields_text = "";
		$last_i = count($fields) - 1;

		$values_text = "";
		$last_j = count($values) - 1;

		for ($i=0; $i < count($fields); $i++) { 
			if($i == $last_i){
				$comma = "";
			}else{
				$comma = ",";
			}
			$fields_text = $fields_text.$fields[$i].$comma;
		}

		for ($j=0; $j < count($values); $j++) { 
			if($j == $last_j){
				$comma = "";
			}else{
				$comma = ",";
			}
			$values_text = $values_text.'"'.$values[$j].'"'.$comma;
		}

		$sql = "INSERT INTO $table_name 
				(".$fields_text.")
				VALUES 
				(".$values_text.")";

		return $result = mysqli_query($conn, $sql);

	}

	function updateRowWithNoCondition($conn, $table_name, $fields, $values){

		if(count($fields) == count($values)){

			$text = "";
			$last_i = count($fields) - 1;

			for ($i=0; $i < count($fields); $i++) { 
				if($i == $last_i){
					$comma = "";
				}else{
					$comma = ",";
				}
				
				$text = $text.$fields[$i].'="'.$values[$i].'"'.$comma;
			}

			$sql = "UPDATE $table_name
						SET ".$text."";

			return $result = mysqli_query($conn, $sql);

		}else{
			return 0;
		}

	}

	function  updateRowWithOneCondition($conn, $table_name, $fields, $values, $condition){

		if(count($fields) == count($values)){

			$text = "";
			$last_i = count($fields) - 1;

			for ($i=0; $i < count($fields); $i++) { 
				if($i == $last_i){
					$comma = "";
				}else{
					$comma = ",";
				}
				
				$text = $text.$fields[$i].'="'.$values[$i].'"'.$comma;
			}

			$sql = "UPDATE $table_name
						SET ".$text."
						WHERE ".conditionDefine($condition);

			return $result = mysqli_query($conn, $sql);

		}else{
			return 0;
		}

	}

	function updateRowWithTwoCondition($conn, $table_name, $fields, $values, $condition_one, $condition_two){

		if(count($fields) == count($values)){

			$text = "";
			$last_i = count($fields) - 1;

			for ($i=0; $i < count($fields); $i++) { 
				if($i == $last_i){
					$comma = "";
				}else{
					$comma = ",";
				}
				
				$text = $text.$fields[$i].'="'.$values[$i].'"'.$comma;
			}

			$sql = "UPDATE $table_name
						SET ".$text."
						WHERE ".conditionDefine($condition_one)."
						AND ".conditionDefine($condition_two);

			return $result = mysqli_query($conn, $sql);

		}else{
			return 0;
		}

	}

	function deleteRowWithOneCondition($conn, $table_name, $condition){

		$sql = "DELETE FROM $table_name
					WHERE ".conditionDefine($condition);

		return $result = mysqli_query($conn, $sql);

	}

	function selectUserList($conn, $get_data = null){

			if (empty($get_data)) {
				
				$sql = "SELECT 
					users.id, users.name, users.msisdn, users.email, users.role_id, roles.title
					FROM users
					JOIN roles ON users.role_id = roles.id";

			}else{
				
				$sql = "SELECT 
					users.id, users.name, users.msisdn, users.email, users.role_id, roles.title
					FROM users
					JOIN roles ON users.role_id = roles.id";

				// echo count($get_data);

				$conditions = array();

				if(array_key_exists('name', $get_data) && $get_data['name'] != ''){
					$conditions[] = 'users.name LIKE "%'.$get_data['name'].'%"';
				}

				if(array_key_exists('msisdn', $get_data) && $get_data['msisdn'] != ''){
					$conditions[] = 'users.msisdn LIKE "%'.$get_data['msisdn'].'%"';
				}

				if(array_key_exists('email', $get_data) && $get_data['email'] != ''){
					$conditions[] = 'users.email LIKE "%'.$get_data['email'].'%"';
				}

				if(array_key_exists('role_id', $get_data) && $get_data['role_id'] != ''){
					$conditions[] = 'users.role_id = '.$get_data['role_id'];
				}

				if(array_key_exists('status', $get_data) && $get_data['status'] != ''){
					$conditions[] = 'users.status = '.$get_data['status'];
				}

				for ($i=0; $i < count($conditions); $i++) { 
					if($i == 0){
						$keyword = "WHERE";
					}else{
						$keyword = "AND";
					}

					$sql = $sql.' '.$keyword.' '.$conditions[$i];

				}

			}

			return $result = mysqli_query($conn, $sql);

		}


	function selectCourseList($conn, $table_name, $get_data = null){

		if (empty($get_data)) {
			
			$sql = "SELECT * FROM $table_name";

		}else{

			$sql = "SELECT * FROM $table_name";

			$conditions = array();

			if(array_key_exists('code', $get_data) && $get_data['code'] != ''){
				$conditions[] = 'code LIKE "%'.$get_data['code'].'%"';
			}

			if(array_key_exists('title', $get_data) && $get_data['title'] != ''){
				$conditions[] = 'title LIKE "%'.$get_data['title'].'%"';
			}

			if(array_key_exists('number_of_class', $get_data) && $get_data['number_of_class'] != ''){
				$conditions[] = 'number_of_class = '.$get_data['number_of_class'];
			}

			if(array_key_exists('duration', $get_data) && $get_data['duration'] != ''){
				$conditions[] = 'duration = '.$get_data['duration'];
			}

			if(array_key_exists('status', $get_data) && $get_data['status'] != ''){
				$conditions[] = 'batches.status = '.$get_data['status'];
			}

			for ($i=0; $i < count($conditions); $i++) { 
				if($i == 0){
					$keyword = "WHERE";
				}else{
					$keyword = "AND";
				}

				$sql = $sql.' '.$keyword.' '.$conditions[$i];

			}
			
		}

		return $result = mysqli_query($conn, $sql);

	}


	function selectBatchList($conn, $get_data= null){

		if (empty($get_data)) {
			
			$sql = "SELECT 
				batches.id, batches.code, batches.title, batches.class_limit, users.name, courses.title AS course_name
				FROM batches
				JOIN users ON batches.trainer_id = users.id
				JOIN courses ON batches.course_id = courses.id";
			

		}else{
			
			$sql = "SELECT 
				batches.id, batches.code, batches.title, batches.class_limit, users.name, courses.title AS course_name
				FROM batches
				JOIN users ON batches.trainer_id = users.id
				JOIN courses ON batches.course_id = courses.id";
				

			

			$conditions = array();

			if(array_key_exists('code', $get_data) && $get_data['code'] != ''){
				$conditions[] = 'batches.code = '.$get_data['code'];
			}

			if(array_key_exists('title', $get_data) && $get_data['title'] != ''){
				$conditions[] = 'batches.title LIKE "%'.$get_data['title'].'%"';
			}

			if(array_key_exists('class_limit', $get_data) && $get_data['class_limit'] != ''){
				$conditions[] = 'batches.class_limit = '.$get_data['class_limit'];
			}

			if(array_key_exists('trainer_name', $get_data) && $get_data['trainer_name'] != ''){
				$conditions[] = 'batches.trainer_id = '.$get_data['trainer_name'];
			}

			if(array_key_exists('course_name', $get_data) && $get_data['course_name'] != ''){
				$conditions[] = 'courses.title LIKE "%'.$get_data['course_name'].'%"';
			}

			if(array_key_exists('status', $get_data) && $get_data['status'] != ''){
				$conditions[] = 'batches.status = '.$get_data['status'];
			}

			for ($i=0; $i < count($conditions); $i++) { 
				if($i == 0){
					$keyword = "WHERE";
				}else{
					$keyword = "AND";
				}

				$sql = $sql.' '.$keyword.' '.$conditions[$i];

			}

		}

		return $result = mysqli_query($conn, $sql);

	}



	function  selectNoticeList($conn, $get_data= null){

		if (empty($get_data)) {
			$sql = "SELECT 
				notices.id, users.name AS name, notices_types.title AS notice_type, notices.title AS notice_title, notices.description, batches.title AS batches_title, notices.start_at,notices.finish_at
				FROM notices
				JOIN users ON notices.created_by = users.id
				JOIN notices_types ON notices.notice_type_id = notices_types.id
				JOIN batches ON notices.batch_id = batches.id";
		}else{

			$sql = "SELECT 
				notices.id, users.name AS name, notices_types.title AS notice_type, notices.title AS notice_title, notices.description, batches.title AS batches_title, notices.start_at, notices.finish_at
				FROM notices
				JOIN users ON notices.created_by = users.id
				JOIN notices_types ON notices.notice_type_id = notices_types.id
				JOIN batches ON notices.batch_id = batches.id";

			$conditions = array();

			if(array_key_exists('created_by', $get_data) && $get_data['created_by'] != ''){
				$conditions[] = 'users.name LIKE "%'.$get_data['created_by'].'%"';
			} 

			if(array_key_exists('notice_type', $get_data) && $get_data['notice_type'] != ''){
				$conditions[] = 'notices_types.title LIKE "%'.$get_data['notice_type'].'%"';
			} 

			if(array_key_exists('title', $get_data) && $get_data['title'] != ''){
				$conditions[] = 'notices.title LIKE "%'.$get_data['title'].'%"';
			}

			if(array_key_exists('batch_id', $get_data) && $get_data['batch_id'] != ''){
				$conditions[] = 'batches.title LIKE "%'.$get_data['batch_id'].'%"';
			} 


			if(array_key_exists('start_date', $get_data) && $get_data['start_date'] != ''){
				$conditions[] = 'notices.start_at LIKE "%'.$get_data['start_date'].'%"';
			}

			if(array_key_exists('finish_date', $get_data) && $get_data['finish_date'] != ''){
				$conditions[] = 'notices.finish_at LIKE "%'.$get_data['finish_date'].'%"';
			}
			if(array_key_exists('status', $get_data) && $get_data['status'] != ''){
				$conditions[] = 'notices.status = '.$get_data['status'];
			}
			for ($i=0; $i < count($conditions); $i++) { 
				if($i == 0){
					$keyword = "WHERE";
				}else{
					$keyword = "AND";
				}

				$sql = $sql.' '.$keyword.' '.$conditions[$i];

			}


		}		 

		
		return $result = mysqli_query($conn, $sql);

	}

	function selectNotice($conn, $all_selected_batches){
			$sql = "SELECT notices.title, notices.description, notices_types.bootstrap_class
					FROM notices 
					JOIN notices_types ON notices_types.id = notices.notice_type_id
					WHERE notices.batch_id IN $all_selected_batches
					ORDER BY notices.id DESC";

			return $result = mysqli_query($conn, $sql);
		}
	

	function selectBatch($conn){
			$sql = "SELECT batches.id, batches.code, batches.title, batches.class_limit

					FROM batches
					JOIN user_batch ON user_batch.batch_id = batches.id
					WHERE user_batch.user_id = ".$_SESSION['user']['id']."
					ORDER BY batches.id DESC";

			return $result = mysqli_query($conn, $sql);
		}

		

	function selectStudentAttendance($conn, $user_id){
			$sql = "SELECT attendances.id, attendances.user_id, attendances.date, attendances.rating, attendances.review, attendances.notes, attendances.approved, batches.title
					FROM attendances
					JOIN batches ON attendances.batch_id = batches.id
					WHERE attendances.user_id = $user_id";
			return $result = mysqli_query($conn, $sql);
		}		


	function selectTrainer($conn){
			$sql = "SELECT batches.id, batches.code, batches.title, batches.class_limit, batches.trainer_id, batches.course_id
					FROM batches
					JOIN batches ON attendances.user_id = batches.id
					WHERE user_batch.user_id = ".$_SESSION['user']['id']."
					ORDER BY batches.id DESC";

			return $result = mysqli_query($conn, $sql);
		}

	function selectTrainerAttendance($conn, $user_id){
			$sql = "SELECT attendances.id, attendances.user_id, attendances.date, attendances.rating, attendances.review, attendances.notes, attendances.approved, batches.title
					FROM attendances
					JOIN batches ON attendances.batch_id = batches.id
					WHERE attendances.user_id = $user_id";
			return $result = mysqli_query($conn, $sql);
		}


	function selectBatchForTrainer($conn, $trainer_id){
			  $sql = "SELECT user_batch.user_id, user_batch.batch_id, batches.title 
			      FROM user_batch
			      JOIN batches ON user_batch.batch_id = batches.id
			      WHERE batches.trainer_id = $trainer_id";
			  return $result = mysqli_query($conn, $sql);
			}

	function pendingAttendances($conn, $all_batchs, $user_id){
		  	$sql = "SELECT attendances.id, attendances.user_id, attendances.date, attendances.rating, attendances.review, attendances.approved, batches.title, users.name
			      FROM attendances
			       JOIN batches ON attendances.batch_id = batches.id
			       JOIN users ON attendances.user_id = users.id
			      WHERE attendances.batch_id IN $all_batchs
			      AND attendances.approved = 0
			      AND attendances.user_id != $user_id";

		  	return $result = mysqli_query($conn, $sql);
		}

	// count student for trainer table
	function batchList($conn){

			$sql = "SELECT batches.id, batches.title, batches.code, COUNT(ub.user_id) AS count_students 
						FROM batches
						JOIN user_batch AS ub ON ub.batch_id = batches.id
						WHERE batches.trainer_id = ".$_SESSION['user']['id']."
						AND batches.status = 1"; 
						
			return $result = mysqli_query($conn, $sql);

	}

	function selectMamagementTrainerAttendance($conn){
		$sql = "SELECT attendances.id, attendances.user_id,attendances.batch_id, attendances.date, attendances.rating, attendances.review, attendances.approved, users.name, batches.title
			FROM attendances
			JOIN users ON attendances.user_id = users.id
			JOIN batches ON attendances.batch_id = batches.id
			WHERE users.role_id = 2";

			return $result = mysqli_query($conn, $sql);
	}

	function pendingTrainerAttendances($conn){
		  	$sql = "SELECT attendances.id, attendances.user_id, attendances.date, attendances.rating, attendances.review, attendances.approved, batches.title, users.name
			      FROM attendances
			       JOIN batches ON attendances.batch_id = batches.id
			       JOIN users ON attendances.user_id = users.id
			      WHERE attendances.approved = 0";

		  	return $result = mysqli_query($conn, $sql);
		}

	function selectMamagementStudentAttendance($conn){
		$sql = "SELECT attendances.id, attendances.user_id,attendances.batch_id, attendances.date, attendances.rating, attendances.review, attendances.approved, users.name, batches.title
			FROM attendances
			JOIN users ON attendances.user_id = users.id
			JOIN batches ON attendances.batch_id = batches.id
			WHERE users.role_id = 3";

			return $result = mysqli_query($conn, $sql);
	}


	function pendingStudentAttendances($conn){
		  	$sql = "SELECT attendances.id, attendances.user_id, attendances.date, attendances.rating, attendances.review, attendances.approved, batches.title, users.name
			      FROM attendances
			      JOIN batches ON attendances.batch_id = batches.id
			      JOIN users ON attendances.user_id = users.id
			      WHERE attendances.approved = 0 
					AND users.role_id = 3
			      ";

		  	return $result = mysqli_query($conn, $sql);
		}

	function viewProfile($conn){

  		$sql = "SELECT users.id, users.name, users.msisdn, users.email, users.image, roles.title AS role
		          FROM users 
		          JOIN roles ON users.role_id = roles.id
		          WHERE users.id = ".$_SESSION['user']['id']."
		          AND users.status = 1
		          ";
		    return $result = mysqli_query($conn, $sql);
	}