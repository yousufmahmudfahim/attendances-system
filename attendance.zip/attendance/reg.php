
<?php 
  include "common/global_config.php";
  include "common/mysql_connect.php";
  include "common/query_builder.php";
  

  // Fatching Roles
  $role_condition_one = array('field_name' => 'status', 'condition' => 'equal', 'field_value' => '1');
  $role_condition_two = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => '3');
  $roles = selectSingleTableWithTwoCondition($conn, 'roles', $role_condition_one, $role_condition_two);

  $role = mysqli_fetch_array($roles);



?>
	

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Attendance System</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

  <!-- jQuery 3 -->
  <script src="<?php echo $base_url; ?>/assets/bower_components/jquery/dist/jquery.min.js"></script>
  
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "common/message.php"; ?>
      
      <h1>
        User
        <small>Registration</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Fill the form</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" action="reg_insert.php">
              <div class="box-body">
                <div class="form-group">
                  <label for="name">Name*</label>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" required="required">
                </div>
                <div class="form-group">
                  <label for="msisdn">Mobile number*</label>
                  <input type="text" name="msisdn" class="form-control" id="msisdn" placeholder="Enter mobile number" required="required">
                </div>
                <div class="form-group">
                  <label for="email">Email address*</label>
                  <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required">
                </div>
                <div class="form-group">
                  <label for="password">Password*</label>
                  <input type="password" name="password" class="form-control" id="password" placeholder="Password" required="required">
                </div>
                <div class="form-group">
                  <label for="password">Confirm password*</label>
                  <input type="password" name="confirm_password" class="form-control" id="confirm_password" placeholder="Confirm password" required="required">

                  <input type="hidden" name="role_id" value="<?php echo $role['id']; ?>" class="form-control" id="role_id" >
                </div>

                <div class="form-group">
                  <label for="image">Photo</label>
                  <input type="file" name="image" id="image">

                  <p class="help-block">Max file size: 2 MB, Format: jpeg, jpg, png</p>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>

              </div>
            </form>
          </div>
          <!-- /.box -->

        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- <script type="text/javascript">
    $(function() {
        nav_highlight("user", "user-add");
    });
  </script> -->

<?php include "common/footer.php"; ?>
