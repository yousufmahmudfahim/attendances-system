<?php
 
	include "common/header.php";

	if(isset($_POST['password']) && $_POST['password'] != ""){

		$fields = array('name', 'msisdn', 'email', 'password');
		$values = array($_POST['name'], $_POST['msisdn'], $_POST['email'], md5($_POST['password']));

	}else{
		
		$fields = array('name', 'msisdn', 'email');
		$values = array($_POST['name'], $_POST['msisdn'], $_POST['email']);

	}

	// $id = $_POST['id'];
	$condition_one =  array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $_SESSION['user']['id']);
	$user = selectSingleTableWithOneCondition($conn, 'users', $condition_one);
	// if(mysqli_num_rows($user) > 0){

		$data = mysqli_fetch_array($user);

		if(isset($_FILES['image']["name"]) && $_FILES['image']["name"] != ''){
			// // Delete Previous
			// $cur_image = $data['image'];
			// $exp_cur_image =explode('/',$cur_image);
			// $last_index = count($exp_cur_image) - 1;
			// $cur_image_file = $exp_cur_image[$last_index];
			// echo $cur_image_file;
			// unlink('/'.$photo_upload_dir.$cur_image_file); exit;

			// Insert New
			$file=$_FILES['image']['name'];
			$expfile=explode('.',$file);
 			$fileexptype=$expfile[1];
 			$file_name = time().$_POST['id'].'.'.$fileexptype;
			$filepath=$photo_upload_dir.$file_name;
			move_uploaded_file($_FILES["image"]["tmp_name"],$filepath);

			$image = $base_url."/".$photo_upload_dir.$file_name;

			$fields[] = 'image';
			$values[] = $image;
			// print_r($image);
		}

		

	    
		$user_condition = array('field_name' => 'id', 'condition' => 'equal', 'field_value' => $_SESSION['user']['id']);
		$result = updateRowWithOneCondition($conn, "users", $fields, $values, $user_condition);

		// print_r($result); exit();


		if($result == 1){
			$_SESSION['success'] = "User updated successfully";
			goToError($base_url."/view.php");
		}else{
			$_SESSION['error'] = "Failed to update user";
			goToError($base_url."/view.php");
		}

	// }else{
	//     $_SESSION['error'] = "Failed to update user";
	// 		goToError($base_url."/view.php");
	// }