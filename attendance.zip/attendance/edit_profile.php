<?php

  include "common/header.php";

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php include "common/message.php"; ?>
      
      <h1>
        User
        <small>Edit</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Fill the form</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="POST" action="profile_update.php" enctype="multipart/form-data">
              <div class="box-body">
                <input type="hidden" name="id" value="<?php $profile_data['id'];; ?>">
                
                <div class="form-group">
                  <label for="name">Name*</label>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" required="required" value="<?php echo $profile_data['name']; ?>">
                </div>
                <div class="form-group">
                  <label for="msisdn">Mobile number*</label>
                  <input type="text" name="msisdn" class="form-control" id="msisdn" placeholder="Enter mobile number" required="required" value="<?php echo $profile_data['msisdn']; ?>">
                </div>
                <div class="form-group">
                  <label for="email">Email address*</label>
                  <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required" value="<?php echo $profile_data['email']; ?>">
                </div>
                <div class="form-group">
                  <label for="password">Password*</label>
                  <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                </div>
                <div class="form-group">
                  <label for="password">Confirm password*</label>
                  <input type="password" name="confirm_password" class="form-control" id="confirm_password" placeholder="Confirm password">
                </div>

                
                <div class="form-group">
                  <label for="image">Photo</label>
                  <input type="file" name="image" id="image">

                  <p class="help-block">Max file size: 2 MB, Format: jpeg, jpg, png</p>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include "common/footer.php"; ?>
